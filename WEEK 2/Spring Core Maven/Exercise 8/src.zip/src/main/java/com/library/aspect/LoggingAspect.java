package com.library.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    // Advice that runs before the execution of any method in BookService
    @Before("execution(* com.library.service.BookService.*(..))")
    public void logBeforeMethodExecution() {
        System.out.println("Executing method in BookService...");
    }

    // Advice that runs after the execution of any method in BookService
    @After("execution(* com.library.service.BookService.*(..))")
    public void logAfterMethodExecution() {
        System.out.println("Method execution in BookService completed.");
    }
}
