package com.library.repository;

import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class BookRepository {
    // Example method to simulate fetching data
    public List<String> findAll() {
        // Simulating a list of books
        return List.of("Book1", "Book2", "Book3");
    }
}
