package com.library.service;

import org.springframework.stereotype.Service;
import com.library.repository.BookRepository;

@Service
public class BookService {
    private BookRepository bookRepository;

    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Example method to demonstrate the use of bookRepository
    public void displayBooks() {
        // Assuming BookRepository has a method findAll()
        bookRepository.findAll().forEach(System.out::println);
    }
}
