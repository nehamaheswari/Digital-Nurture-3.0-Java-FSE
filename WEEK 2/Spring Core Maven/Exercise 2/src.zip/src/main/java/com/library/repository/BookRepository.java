package com.library.repository;

import java.util.Arrays;
import java.util.List;

public class BookRepository {

    public List<String> findAll() {
        return Arrays.asList("The Great Gatsby", "Moby Dick", "1984");
    }
}
